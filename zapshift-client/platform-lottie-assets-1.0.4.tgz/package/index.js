import fota-arrow-dark from './lotties/fota-arrow-dark.json' assert { type: "json" };
import fota-arrow-light from './lotties/fota-arrow-light.json' assert { type: "json" };
import graphic-dark-login from './lotties/graphic-dark-login.json' assert { type: "json" };
import graphic-light-login from './lotties/graphic-light-login.json' assert { type: "json" };
import info-blackvue-light-android-wifi-connect-manually from './lotties/info-blackvue-light-android-wifi-connect-manually.json' assert { type: "json" };
import info-blackvue-light-android-wifi-disconnect-manually from './lotties/info-blackvue-light-android-wifi-disconnect-manually.json' assert { type: "json" };
import info-blackvue-light-ios-wifi-connect-manually from './lotties/info-blackvue-light-ios-wifi-connect-manually.json' assert { type: "json" };
import info-blackvue-light-ios-wifi-disconnect-manually from './lotties/info-blackvue-light-ios-wifi-disconnect-manually.json' assert { type: "json" };
import logo-blackvue-dark-splash from './lotties/logo-blackvue-dark-splash.json' assert { type: "json" };
import logo-blackvue-light-splash from './lotties/logo-blackvue-light-splash.json' assert { type: "json" };
import spinner-blackvue-dark-loading from './lotties/spinner-blackvue-dark-loading.json' assert { type: "json" };
import spinner-blackvue-light-loading from './lotties/spinner-blackvue-light-loading.json' assert { type: "json" };
import touch-sensor-blackvue-dark from './lotties/touch-sensor-blackvue-dark.json' assert { type: "json" };
import touch-sensor-blackvue-light from './lotties/touch-sensor-blackvue-light.json' assert { type: "json" };

export { fota-arrow-dark, fota-arrow-light, graphic-dark-login, graphic-light-login, info-blackvue-light-android-wifi-connect-manually, info-blackvue-light-android-wifi-disconnect-manually, info-blackvue-light-ios-wifi-connect-manually, info-blackvue-light-ios-wifi-disconnect-manually, logo-blackvue-dark-splash, logo-blackvue-light-splash, spinner-blackvue-dark-loading, spinner-blackvue-light-loading, touch-sensor-blackvue-dark, touch-sensor-blackvue-light };